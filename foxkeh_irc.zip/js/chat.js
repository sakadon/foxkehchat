jQuery.noConflict();
(function($) {
	
	// show progressbar
	$('#connecting').show();
	
	/*
	 * メッセージ表示secitonの作成
	 * @param	ch		チャネル
	 * @return	ch_id	idとなったチャネル名文字列を返す
	 */
	function createMsg( ch ){
		
		var id = ch.replace(/#/g,'');
		
		var html = '\
		<section id="'+id+'">\
			<h2>'+ ch +'</h2>\
			<ol class="chat">\
				<li><em>Join</em> '+ch+'</li>\
			</ol>\
		</section>';
		
		$('#msg').prepend(html);
		
		console.log( 'createMsg: ' + ch + ' => id: ' + id );
		return id;
	}
	
	/**
	 * ターゲットに発言htmlをprependしちゃう
	 * @param	ch		チャネル
	 * @param	nick	名前
	 * @param	
	 */
	function prependChat( ch, ch_id, nick, text ){
		
		if( nick == 'undefined' ){ nick = 'Console'; }
		
		console.log( 'prependChat: ' + ch_id[ch] + '//' + nick + '>' + text );
		var html ='\
		<li>\
			<em>&lt;'+ nick + '&gt;</em>\
			' + text +'\
		</li>';
		
		$( '#' + ch_id[ch] + ' .chat').prepend(html);
	}
	

	window.addEventListener('DOMContentLoaded', function( ) {

		// get settings
		var nickname = storageGet( 'nickname' );
		var username = storageGet( 'username' );
		var name = storageGet( 'name' );
		var host = storageGet( 'host' );
		var port = storageGet( 'port' );
		var ch = storageGet( 'ch' );
		var ch_id = {};
		var chat = new Client( host, nickname, {
			port: port,
			userName: username,
			realName: 'FoxkehChat on FirefoxOS',
			//stripColors: true,
			autoConnect: false, // require call client.connect()
			debug: true,
			//channels: [ch],
		});
		
		// Backlog section create
		ch_id[ 'backlog' ] = createMsg( 'backlog' );
		
		// Header my nickname display
		$('#input h2').append( ' ' + nickname );
		
		
		// Connect
		chat.connect( 5, function(e) {
			
			$('#connecting').val('40'); // progress
			
			// Self JOIN
			chat.join( ch, function() {
				
				$('#connecting').val('60'); // progress
				
				console.log( 'SELF JOIN: ' + ch );
				
				// CH section create
				ch_id[ ch ] = createMsg( ch );
				
				console.log( ch_id );
				
				$('#connecting').val('100').slideUp('slow'); // progress

			});
			
		});
		
		// Say Send Message
		$('#say').keypress( function( event ) {
			if( event.which === 13 ){
				
				var text = $(this).val();
				var say_text = textEncode(text,'utf-8');
				
				chat.say( ch, say_text );
				
				prependChat( ch, ch_id, nickname, text );
				
				$(this).val('');
				
			}
		});
		
		
		
		// Other Join
		chat.addListener('join', function(channel, nick, message) {
			
			console.log( 'JOIN: ' + channel );
			console.log( message );
			
			
			
		});
		
		// Msg
		chat.addListener('message', function (nick, to, text, message) {
			console.log('MESSAGE: ' + nick + ' => ' + to + ': ' + text);
			console.log(message);
			
			// decode
			text = textDecode( text );
			
			if( to == ch ){
				prependChat( ch, ch_id, nick, text );
			} else {
				prependChat( 'backlog', ch_id, nick, text );
			}
		});
		
		// Notice
		chat.addListener('notice', function (nick, to, text, message) {
			console.log('NOTICE: '+ nick + ' => ' + to + ': ' + text);
			console.log(message);
			
			// decode
			text = textDecode( text );
			
			if( to == ch ){
				prependChat( ch, ch_id, nick, text );
			} else if( nick == undefined ) {
				prependChat( 'backlog', ch_id, 'Console', text );
			} else {
				prependChat( 'backlog', ch_id, nick, text );
			}
		});

		
		// Priv
		chat.addListener('pm', function (nick, text, message) {
			console.log('PM: ' + nick + ' => ME: ' + text );
			console.log(message);
			
			text = textDecode( text );
			
			prependChat( 'backlog', ch_id, nick, text );
		});

		
		// Error
		chat.addListener('error', function(text) {
			console.log('error: ', text);
			
			text = textDecode( text );
			
			prependChat( 'backlog', ch_id, 'Error', text );
		});
		
		
		// Disconnect
		$('#disconnect').on('click', function(){
			
			var result = window.confirm( 'Disconnect ok?' );
			
			// Confirm YES
			if( result == true ){
				
				// chat disconnect
				chat.disconnect( "byebye", function() {
					console.log("DISCONNECT");
					
					delete chat;
					$('#msg').empty();
					
					window.location.href = '/index.html?disconnect=true';
				});
				
			}
		});
		
	
	});
	
})(jQuery);
